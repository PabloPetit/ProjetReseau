//
//  lecteur.h
//  Client
//
//  Created by Pablo Petit on 11/05/2015.
//  Copyright (c) 2015 Pablo Petit. All rights reserved.
//

#ifndef __Client__lecteur__
#define __Client__lecteur__

#include <stdio.h>
#include "diffuseur.h"

void * run_lecteur(void *);

#endif /* defined(__Client__lecteur__) */
