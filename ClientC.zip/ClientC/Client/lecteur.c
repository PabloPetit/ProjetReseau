//
//  lecteur.c
//  Client
//
//  Created by Pablo Petit on 11/05/2015.
//  Copyright (c) 2015 Pablo Petit. All rights reserved.
//

#include "lecteur.h"




void * run_lecteur(void * arg){
    extern liste_dif * liste;
    extern pthread_mutex_t verrou;
    
    return NULL;
}