#ifndef __Client__menu_principal__
#define __Client__menu_principal__

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "main.h"
#include "messages.h"
#include "diffuseur.h"
#include "saisie.h"
#include "gestionnaire.h"

int menu_principal();

#endif 
