#ifndef Client_main_h
#define Client_main_h

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "getch.h"
#include "menu_principal.h"
#include "menu.h"
#include "saisie.h"
#include "lecteur.h"

void saisie_id();
void format_id(char *,char *);
int  saisie_tty_out();
#endif
