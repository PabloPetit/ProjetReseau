#ifndef __Menu__menu__
#define __Menu__menu__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ncurses.h>

int capture_select(int,int);
int run(char *, char * args[],int);

#endif
