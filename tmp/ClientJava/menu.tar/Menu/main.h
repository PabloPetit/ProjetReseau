//
//  Header.h
//  Menu
//
//  Created by Pablo Petit on 17/04/2015.
//  Copyright (c) 2015 Pablo Petit. All rights reserved.
//

#ifndef Menu_main_h
#define Menu_main_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include "menu.h"

#endif
